package internet.pages;

import internet.core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class FileUploaderPage extends BasePage {

    private By fileInput = By.id("file-upload");
    private By uploadButton = By.id("file-submit");
    private By uploadedFileName = By.id("uploaded-files");

    public FileUploaderPage(WebDriver driver) {
        super(driver);
    }

    public FileUploaderPage uploadFile(String filePath) {
        uploadFile(fileInput, filePath);
        driver.findElement(uploadButton).click();
        return this;
    }

    public void verifyUploadedFileName(String expectedFileName) {
        String actualFileName = driver.findElement(uploadedFileName).getText();
        Assert.assertTrue(actualFileName.contains(expectedFileName),
                "Expected file name: " + expectedFileName + " but found: " + actualFileName);
    }
}


